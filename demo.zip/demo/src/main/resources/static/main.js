//main.js
let allCoursesRawData = []; // 存放從後端取得的所有原始課程資料
const API_BASE = 'http://localhost:8080/api';

// 1. 動態抓取從 login.html 存入的使用者資料（若未登入則為 null）
const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));

// 2. 初始化載入
window.onload = function() {
    // 判斷當前在哪個頁面
    const isInsideAdminPage = window.location.pathname.includes('admin.html');
    
    if (isInsideAdminPage) {
        // 🔒 後台安全防護：如果未登入或不是 ADMIN，強制踢回首頁
        if (!currentUser || currentUser.role !== 'ADMIN') {
            alert('❌ 權限不足！此頁面僅供管理員存取。');
            window.location.href = 'index.html';
            return;
        }
    } else {
        // 如果在前台，才需要加載課程清單
        loadCourses();
    }
    
    updateAuthUI();
    updateAiButtonStatus(); // 🎯 【新增】網頁一打開，立刻根據登入狀態上鎖或解鎖 AI 按鈕
};

// 更新網頁上的登入狀態顯示與後台權限控管
function updateAuthUI() {
    const userInfoEl = document.getElementById('userInfo');
    const loginBtnEl = document.getElementById('loginBtn');
    const logoutBtnEl = document.getElementById('logoutBtn');
    const adminBtnEl = document.getElementById('adminBtn'); // 👈 前台的「進入後台」按鈕
    
    if (currentUser) {
        if (userInfoEl) userInfoEl.innerText = `你好，${currentUser.username} (${currentUser.role})`;
        if (loginBtnEl) loginBtnEl.style.display = 'none';
        if (logoutBtnEl) logoutBtnEl.style.display = 'inline-block'; // 顯示登出
        
        // 只有 ADMIN 可以在前台看到「進入後台」按鈕
        if (adminBtnEl) {
            adminBtnEl.style.display = (currentUser.role === 'ADMIN') ? 'inline-block' : 'none';
        }
    } else {
        if (userInfoEl) userInfoEl.innerText = '訪客模式';
        if (loginBtnEl) loginBtnEl.style.display = 'inline-block';
        if (logoutBtnEl) logoutBtnEl.style.display = 'none';
        if (adminBtnEl) adminBtnEl.style.display = 'none';
    }
}

// 🔓 【新功能】登出邏輯
function logout() {
    if (confirm('確定要登出系統嗎？')) {
        sessionStorage.clear(); // 抹除所有登入暫存資料
        alert('已成功登出！');
        window.location.href = 'index.html'; // 強制跳回首頁
    }
}

// 🚀 發送 POST 請求觸發後端爬蟲更新
function triggerCrawler() {
    if (!currentUser || currentUser.role !== 'ADMIN') {
        alert("❌ 權限不足！您不是系統管理員。");
        return;
    }

    const year = document.getElementById('crawlYear').value;
    const semester = document.getElementById('crawlSemester').value;
    
    const startBtn = document.getElementById('startCrawlBtn');
    const spinner = document.getElementById('crawlSpinner');
    const statusText = document.getElementById('crawlStatus');
    const successText = document.getElementById('crawlSuccessStatus');

    if (!year || !semester) {
        alert("請輸入正確的學年度與學期！");
        return;
    }

    if (!confirm(`⚠️ 管理員驗證成功。確定要重置資料庫並同步【 ${year} 學年度第 ${semester} 學期】課程嗎？`)) {
        return;
    }

    startBtn.disabled = true;
    successText.classList.add('d-none');
    spinner.classList.remove('d-none');
    spinner.classList.add('d-flex');

    fetch(`${API_BASE}/admin/crawler/start?year=${year}&semester=${semester}`, {
        method: 'POST',
        headers: { 'User-Role': currentUser.role }
    })
    .then(async res => {
        if (res.status === 403) throw new Error('後端拒絕存取：您不具備管理員權限！');
        if (!res.ok) throw new Error('伺服器處理異常。');
        return res.json();
    })
    .then(data => {
        alert(`🎉 ${data.message}\n資料庫重置完畢，共成功洗入：${data.totalProcessed} 門課程！`);
        successText.innerText = `✅ 成功同步 ${data.totalProcessed} 門課程！`;
        successText.classList.remove('d-none');
    })
    .catch(err => {
        console.error('爬蟲失敗:', err);
        alert(`❌ 同步失敗：${err.message}`);
    })
    .finally(() => {
        startBtn.disabled = false;
        spinner.classList.remove('d-flex');
        spinner.classList.add('d-none');
    });
}

// 載入課程清單
// 修改後的 loadCourses()
function loadCourses() {
    fetch(`${API_BASE}/courses`)
        .then(res => res.json())
        .then(courses => {
            allCoursesRawData = courses;
            
            // 初始化系所 Checkbox 事件監聽
            const checkboxes = document.querySelectorAll('.dept-checkbox');
            checkboxes.forEach(cb => {
                cb.removeEventListener('change', applyCombinedFilter);
                cb.addEventListener('change', applyCombinedFilter);
            });

            // 初始化教師選單
            initProfessorCheckbox();

            // 💡 新增：根據 SDGS_MAP 初始化「SDGs 選單」
            initSdgsCheckbox();

            // 初始化 Modal 的第一層「系所下拉選單」
            initModalDeptSelect();

            updateModalCourseSelect(courses);

            applyCombinedFilter();
        })
        .catch(err => {
            console.error('無法載入課程清單:', err);
            const container = document.getElementById('courseContainer');
            if (container) container.innerHTML = '<p class="text-danger text-center">無法載入課程資料，請確認後端是否啟動。</p>';
        });
}

// 💡 新增功能：根據 SDGS_MAP 動態生成 SDGs 的 Checkbox 清單
function initSdgsCheckbox() {
    const sdgsMenu = document.getElementById('sdgsDropdownMenu');
    if (!sdgsMenu) return;

    let html = `
        <div class="d-flex justify-content-between border-bottom pb-2 mb-2">
            <button type="button" class="btn btn-xs btn-link p-0 text-success small" onclick="filterAllSdgs(true)">全選</button>
            <button type="button" class="btn btn-xs btn-link p-0 text-muted small" onclick="filterAllSdgs(false)">全不選</button>
        </div>
    `;

    // 依據 01 到 17 排序填入
    Object.keys(SDGS_MAP).sort().forEach(key => {
        html += `
            <li>
                <label class="dropdown-item">
                    <input type="checkbox" class="sdgs-checkbox me-2" value="${key}" checked> 
                    <span class="badge bg-success me-1">${key}</span> ${SDGS_MAP[key]}
                </label>
            </li>
        `;
    });

    sdgsMenu.innerHTML = html;

    // 監聽所有 SDGs Checkbox
    const sdgsCheckboxes = document.querySelectorAll('.sdgs-checkbox');
    sdgsCheckboxes.forEach(cb => {
        cb.addEventListener('change', applyCombinedFilter);
    });
}

// 💡 新增功能：SDGs 選單的全選 / 全不選控制
function filterAllSdgs(isSelected) {
    const checkboxes = document.querySelectorAll('.sdgs-checkbox');
    checkboxes.forEach(cb => { cb.checked = isSelected; });
    applyCombinedFilter();
}

// 💡 新增功能：動態將 DEPT_MAP 的內容塞入 Modal 的第一個系所下拉選單
function initModalDeptSelect() {
    const deptSelect = document.getElementById('modalDeptSelect');
    if (!deptSelect) return;

    // 清空並加入預設選項
    deptSelect.innerHTML = '<option value="">-- 請選擇系所 --</option>';

    // 依據 DEPT_MAP 的 key/value 動態生成 option
    Object.keys(DEPT_MAP).forEach(key => {
        const option = document.createElement('option');
        option.value = key;
        option.innerText = `${DEPT_MAP[key]} (${key})`;
        deptSelect.appendChild(option);
    });

    // 💡 關鍵監聽：當第一層「系所」改變時，觸發第二層「課程」更新
    deptSelect.removeEventListener('change', handleDeptChange); // 防重複綁定
    deptSelect.addEventListener('change', handleDeptChange);
}

// 💡 新增功能：處理系所切換時的連動邏輯
function handleDeptChange(e) {
    const selectedDeptCode = e.target.value;
    const courseSelect = document.getElementById('modalCourseSelect');
    if (!courseSelect) return;

    if (!selectedDeptCode) {
        // 如果使用者選回預設的空值，把第二層清空並鎖定
        courseSelect.innerHTML = '<option value="">-- 請先選擇系所 --</option>';
        courseSelect.disabled = true;
        return;
    }

    // 1. 從全域原始資料中，過濾出符合該系所的課程
    const filteredCourses = allCoursesRawData.filter(course => {
        return (course.department || '').toUpperCase().trim() === selectedDeptCode.toUpperCase().trim();
    });

    // 2. 重新填充第二層「課程」下拉選單
    courseSelect.innerHTML = '<option value="">-- 請選擇課程 --</option>';
    
    if (filteredCourses.length === 0) {
        courseSelect.innerHTML = '<option value="">⚠️ 該系所目前無開課資料</option>';
        courseSelect.disabled = true;
        return;
    }

    filteredCourses.forEach(course => {
        const option = document.createElement('option');
        option.value = course.id;
        // 因為已經分系所了，名稱這裡可以主要呈現 [課號] 教授 - 課名
        option.innerText = `${course.courseCode || '無課號'} | ${course.professor || '未排教師'} - ${course.courseName}`;
        courseSelect.appendChild(option);
    });

    // 3. 解除鎖定，讓使用者可以點選
    courseSelect.disabled = false;
}

// 💡 新增功能：從原始資料中提取所有不重複的教授，並動態生成 Checkbox 選單
// 💡 修改功能：將合開的教授名稱切開，提取出真正獨立的不重複教授名單
function initProfessorCheckbox() {
    const profMenu = document.getElementById('profDropdownMenu');
    if (!profMenu) return;

    const profSet = new Set();

    allCoursesRawData.forEach(c => {
        const profStr = (c.professor || '').trim();
        if (profStr && profStr !== '未安排教師') {
            
            //【超強效全面切字邏輯】
            // 包含：半形全形逗號(,,，)、斜線(/\)、中英文頓號(、)、所有空格(半形、全形\u3000、換行)
            const splitProfs = profStr.split(/[,，/\\、\s\u3000\n\r]+/);
            
            splitProfs.forEach(p => {
                const cleanName = p.trim();
                // 排除空白、常見無效字眼
                if (cleanName !== '' && cleanName !== '教授' && cleanName !== '老師') {
                    profSet.add(cleanName); 
                }
            });
        }
    });

    // 轉換成陣列並排序
    const professors = [...profSet].sort();

    // 建立「全選」與「全不選」快捷按鈕
    let html = `
        <div class="d-flex justify-content-between border-bottom pb-2 mb-2">
            <button type="button" class="btn btn-xs btn-link p-0 text-primary small" onclick="filterAllProfessors(true)">全選</button>
            <button type="button" class="btn btn-xs btn-link p-0 text-muted small" onclick="filterAllProfessors(false)">全不選</button>
        </div>
    `;

    // 動態填入純單一教授的 Checkbox
    professors.forEach((prof, index) => {
        html += `
            <li>
                <label class="dropdown-item">
                    <input type="checkbox" class="prof-checkbox me-2" value="${prof}" checked> ${prof}
                </label>
            </li>
        `;
    });

    profMenu.innerHTML = html;

    // 重新綁定事件
    const profCheckboxes = document.querySelectorAll('.prof-checkbox');
    profCheckboxes.forEach(cb => {
        cb.addEventListener('change', applyCombinedFilter);
    });
}

// 💡 新增功能：教師選單的全選 / 全不選控制
function filterAllProfessors(isSelected) {
    const checkboxes = document.querySelectorAll('.prof-checkbox');
    checkboxes.forEach(cb => {
        cb.checked = isSelected;
    });
    applyCombinedFilter();
}

// 💡 終極進化：系所 X 教師 X SDGs 三條件交叉過濾器
function applyCombinedFilter() {
    const container = document.getElementById('courseContainer');
    if (!container) return;

    // 1. 收集系所狀態
    const checkedDepts = document.querySelectorAll('.dept-checkbox:checked');
    const totalDepts = document.querySelectorAll('.dept-checkbox').length;
    const selectedDepts = Array.from(checkedDepts).map(cb => cb.value);

    // 2. 收集教師狀態
    const checkedProfs = document.querySelectorAll('.prof-checkbox:checked');
    const totalProfs = document.querySelectorAll('.prof-checkbox').length;
    const selectedProfs = Array.from(checkedProfs).map(cb => cb.value);

    // 3. 💡 新增：收集 SDGs 狀態
    const checkedSdgs = document.querySelectorAll('.sdgs-checkbox:checked');
    const totalSdgs = document.querySelectorAll('.sdgs-checkbox').length;
    const selectedSdgs = Array.from(checkedSdgs).map(cb => cb.value);

    // 4. 核心交叉過濾 (AND 邏輯)
    const filteredCourses = allCoursesRawData.filter(course => {
        // (A)系所過濾
        let matchDept = (checkedDepts.length === totalDepts) || selectedDepts.includes((course.department || '').toUpperCase().trim());

        // (B)升級：教師包含過濾邏輯（支援合開課程，如 "A, B" 老師）
        let matchProf = false;
        if (checkedProfs.length === totalProfs) {
            matchProf = true; // 全選直接通關
        } else if (checkedProfs.length === 0) {
            matchProf = false; // 全部不選時，直接不顯示
        } else {
            //只要被勾選的老師名單 (selectedProfs) 中，有任何一位被包含在該課程的 professor 欄位裡，就算有
            const courseProfStr = (course.professor || '').trim();
            matchProf = selectedProfs.some(prof => courseProfStr.includes(prof));
        }

        // (C) 💡 新增：SDGs 過濾邏輯
        let matchSdgs = false;
        if (checkedSdgs.length === totalSdgs) {
            matchSdgs = true; // 全選直接通關
        } else {
            // 將課程的 "01,08,02" 拆成陣列
            const courseSdgsList = course.sdgs ? course.sdgs.split(',').map(s => s.trim()) : [];
            // 只要課程擁有的 SDGs 與使用者勾選的 SDGs 有任何交集，就算符合條件
            matchSdgs = courseSdgsList.some(sdg => selectedSdgs.includes(sdg));
        }

        // 三個條件必須同時滿足 (AND)
        return matchDept && matchProf && matchSdgs;
    });

    // 5. 更新 UI 狀態文字
    const deptDropdownBtn = document.getElementById('deptDropdownBtn');
    if (deptDropdownBtn) {
        if (selectedDepts.length === 0) deptDropdownBtn.innerText = '選擇系所 (已全部不選)';
        else if (selectedDepts.length === totalDepts) deptDropdownBtn.innerText = '選擇系所 (已選擇: 全選)';
        else deptDropdownBtn.innerText = `選擇系所 (已選 ${selectedDepts.length} 個)`;
    }

    const profDropdownBtn = document.getElementById('profDropdownBtn');
    if (profDropdownBtn) {
        if (selectedProfs.length === 0) profDropdownBtn.innerText = '選擇教師 (已全部不選)';
        else if (selectedProfs.length === totalProfs) profDropdownBtn.innerText = '選擇教師 (已選擇: 全選)';
        else profDropdownBtn.innerText = `選擇教師 (已選 ${selectedProfs.length} 位)`;
    }

    // 💡 新增：更新 SDGs 按鈕文字
    const sdgsDropdownBtn = document.getElementById('sdgsDropdownBtn');
    if (sdgsDropdownBtn) {
        if (selectedSdgs.length === 0) sdgsDropdownBtn.innerText = '選擇 SDGs (已全部不選)';
        else if (selectedSdgs.length === totalSdgs) sdgsDropdownBtn.innerText = '選擇 SDGs (已選擇: 全選)';
        else sdgsDropdownBtn.innerText = `選擇 SDGs (已選 ${selectedSdgs.length} 項指標)`;
    }

    // 更新計數提示
    const filterCountInfo = document.getElementById('filterCountInfo');
    if (filterCountInfo) {
        filterCountInfo.innerText = `目前顯示：${filteredCourses.length} 門課程 / 總共：${allCoursesRawData.length} 門課程`;
    }

    // 6. 渲染卡片
    container.innerHTML = '';
    if (filteredCourses.length === 0) {
        container.innerHTML = '<div class="col-12 text-center text-muted py-5">⚠️ 沒有符合 (系所 X 教師 X SDGs) 交叉條件的課程。</div>';
        return;
    }

    // ... (底下的 card.innerHTML 渲染邏輯保持不變，照舊即可) ...
    filteredCourses.forEach(course => {
        const card = document.createElement('div');
        card.className = 'col-md-4 mb-4';
        const ratingDisplay = (course.averageRating === 0) 
            ? `<span class="badge bg-secondary text-white">尚無評分</span>` 
            : `<span class="badge bg-warning text-dark">評分：${course.averageRating.toFixed(1)} / 5.0</span>`;

        // 🎯 【新增】卡片列表教室名稱轉換渲染
        let displayClassroom = course.classroom || '未定';
        if (course.classroom) {
            for (const [code, buildingName] of Object.entries(BUILDING_MAP)) {
                if (course.classroom.toUpperCase().startsWith(code)) {
                    displayClassroom = course.classroom.replace(new RegExp(code, 'i'), `${buildingName}(${code})`);
                    break;
                }
            }
        }

        card.innerHTML = `
            <div class="card h-100 shadow-sm">
                <div class="card-body">
                    <div class="text-primary fw-bold mb-1">
                        <span class="badge bg-primary me-1">${course.department || '未知'}</span> 
                        ${course.courseCode || '未設定代碼'}
                    </div>
                    <h5 class="card-title text-truncate" title="${course.courseName}">${course.courseName}</h5>
                    <h6 class="card-subtitle mb-2 text-muted">👤 教授：${course.professor || '未安排教師'}</h6>
                    <div class="text-muted small mb-2">
                        <i class="bi bi-clock me-1"></i> 時間：週${course.classDay || '無'}${course.classPeriod ? '第 '+course.classPeriod+' 節' : ''} 
                        <br>
                        <i class="bi bi-geo-alt me-1"></i> 教室：${course.classroom || '未定'}
                    </div>
                    <p class="card-text mb-0">${ratingDisplay}</p>
                </div>
                <div class="card-footer bg-white d-flex gap-2 justify-content-end">
                    <button class="btn btn-outline-primary btn-sm" onclick="viewCourseDetail(${course.id})">詳細資訊</button>
                    <button class="btn btn-outline-secondary btn-sm" onclick="viewReviews(${course.id}, '${course.courseName}')">查看評論</button>
                </div>
            </div>
        `;
        container.appendChild(card);
    });
}

function filterAllDepartments(isSelected) {
    const checkboxes = document.querySelectorAll('.dept-checkbox');
    checkboxes.forEach(cb => { cb.checked = isSelected; });
    applyCombinedFilter(); // 改呼叫綜合篩選
}

// 💡 修改：原本用來填充全部課程的方法可以封印或保留，但我們現在在表單提交後重置它
function updateModalCourseSelect(courses) {
    // 這裡我們只做基本重置，因為真正的填充已經移到連動 handleDeptChange 去了
    const courseSelect = document.getElementById('modalCourseSelect');
    if (courseSelect) {
        courseSelect.innerHTML = '<option value="">-- 請先選擇系所 --</option>';
        courseSelect.disabled = true;
    }
    const deptSelect = document.getElementById('modalDeptSelect');
    if (deptSelect) {
        deptSelect.value = '';
    }
}

// 開啟新增評論 Modal
function openReviewModal() {
    if (!currentUser) {
        alert('🔒 請先登入會員，才能新增評論功能喔！將為您引導至登入頁面。');
        window.location.href = 'login.html';
        return;
    }
    const modal = new bootstrap.Modal(document.getElementById('reviewModal'));
    modal.show();
}

// 提交評論表單
document.getElementById('reviewForm').addEventListener('submit', function(e) {
    e.preventDefault();
    if (!currentUser) {
        alert('🔒 連線逾時或未登入，請重新登入！');
        window.location.href = 'login.html';
        return;
    }
    const courseIdVal = document.getElementById('modalCourseSelect').value;
    if (!courseIdVal) {
        alert('請選擇要評論的課程！');
        return;
    }
    const reviewData = {
        courseId: parseInt(courseIdVal),
        userId: currentUser.id,          
        username: currentUser.username,  
        rating: parseInt(document.getElementById('modalRating').value),
        content: document.getElementById('modalContent').value
    };
    fetch(`${API_BASE}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reviewData)
    })
    .then(res => {
        if (!res.ok) throw new Error('網頁回應不正常');
        return res.json();
    })
    .then(() => {
        alert('🎉 評論提交成功！');
        document.getElementById('reviewForm').reset();
        
        // 💡 新增：成功重置表單後，讓第二層課程選單重新回復鎖定狀態
        const courseSelect = document.getElementById('modalCourseSelect');
        if (courseSelect) {
            courseSelect.innerHTML = '<option value="">-- 請先選擇系所 --</option>';
            courseSelect.disabled = true;
        }

        const modalElement = document.getElementById('reviewModal');
        const modalInstance = bootstrap.Modal.getInstance(modalElement);
        if (modalInstance) modalInstance.hide();
        loadCourses();
    })
    .catch(err => {
        console.error('送出評論失敗:', err);
        alert('評論送出失敗，請檢查後端連線！');
    });
});

// 查看特定的課程評論清單
// 查看特定的課程評論清單
function viewReviews(courseId, courseName) {
    // 🎯 升級：如果已登入，就把目前 user 的 id 帶給後端判定是否點過讚
    const currentUserId = currentUser ? currentUser.id : '';
    
    fetch(`${API_BASE}/reviews/course/${courseId}?userId=${currentUserId}`)
    .then(res => res.json())
    .then(reviews => {
        const viewModalLabel = document.getElementById('viewModalLabel');
        if (viewModalLabel) viewModalLabel.innerText = `${courseName} - 他人評論`;

        const container = document.getElementById('reviewsListContainer');
        if (!container) return;
        container.innerHTML = ''; 

        if (reviews.length === 0) {
            container.innerHTML = '<p class="text-muted text-center py-3">目前這門課還沒有任何評論，快來當第一個評論的人吧！</p>';
        } else {
            reviews.forEach(review => {
                const item = document.createElement('div');
                item.className = 'border-bottom py-3 mb-2';
                const stars = '⭐'.repeat(review.rating);
                const dateStr = review.createdAt ? new Date(review.createdAt).toLocaleString() : '';
                
                // 🎯 判斷讚按鈕外觀樣式
                const likeBtnClass = review.userReaction === 'LIKE' ? 'btn-primary' : 'btn-outline-primary';
                const dislikeBtnClass = review.userReaction === 'DISLIKE' ? 'btn-danger' : 'btn-outline-danger';

                item.innerHTML = `
                    <div class="d-flex justify-content-between mb-1">
                        <strong>👤 ${review.username || '匿名同學'}</strong>
                        <span class="text-warning">${stars}</span>
                    </div>
                    <p class="mb-1 text-secondary" style="white-space: pre-line;">${review.content}</p>
                    
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <small class="text-muted" style="font-size: 0.8rem;">發布時間：${dateStr}</small>
                        
                        <div class="btn-group btn-group-sm" role="group">
                            <button type="button" class="btn ${likeBtnClass} px-3" id="like-btn-${review.id}" onclick="handleReaction(${review.id}, 'LIKE')">
                                👍 <span id="like-count-${review.id}">${review.likeCount}</span>
                            </button>
                            <button type="button" class="btn ${dislikeBtnClass} px-3" id="dislike-btn-${review.id}" onclick="handleReaction(${review.id}, 'DISLIKE')">
                                👎 <span id="dislike-count-${review.id}">${review.dislikeCount}</span>
                            </button>
                        </div>
                    </div>
                `;
                container.appendChild(item);
            });
        }
        const viewModalElement = document.getElementById('viewReviewsModal');
        if (viewModalElement) {
            const viewModal = new bootstrap.Modal(viewModalElement);
            viewModal.show();
        }
    })
    .catch(err => {
        console.error('讀取評論失敗:', err);
        alert('無法取得評論，請確認後端是否正常運行。');
    });
}

// 🎯 【全新新增】處理前端按讚、倒讚點擊的異步發送函數
function handleReaction(reviewId, type) {
    if (!currentUser) {
        alert('🔒 請先登入會員，才能使用評分按讚功能喔！');
        return;
    }

    fetch(`${API_BASE}/reviews/${reviewId}/react?userId=${currentUser.id}&type=${type}`, {
        method: 'POST'
    })
    .then(res => {
        if (!res.ok) throw new Error('伺服器回應異常');
        return res.json();
    })
    .then(data => {
        // data 結構為 { likeCount: x, dislikeCount: y, userReaction: '...' }
        // 1. 更新計數器數字
        document.getElementById(`like-count-${reviewId}`).innerText = data.likeCount;
        document.getElementById(`dislike-count-${reviewId}`).innerText = data.dislikeCount;

        // 2. 動態刷新按鈕高亮外觀
        const likeBtn = document.getElementById(`like-btn-${reviewId}`);
        const dislikeBtn = document.getElementById(`dislike-btn-${reviewId}`);

        // 重置為預清外框樣式
        likeBtn.className = "btn btn-sm px-3 " + (data.userReaction === 'LIKE' ? 'btn-primary' : 'btn-outline-primary');
        dislikeBtn.className = "btn btn-sm px-3 " + (data.userReaction === 'DISLIKE' ? 'btn-danger' : 'btn-outline-danger');
    })
    .catch(err => {
        console.error('切換按讚狀態失敗:', err);
        alert('操作失敗，請重新再試！');
    });
}

// 🎯 1. 修正：系所對照表（已全面移除中文字後面的括號英文，如 GR、SO 等）
const DEPT_MAP = {
    "GR": "共同必修", "CC": "核心通識", "LI": "通識人文科學類",
    "SC": "通識自然科學類", "SO": "通識社會科學類", "CD": "全民國防教育類",
    "IN": "興趣選修", "WL": "西洋語文學系", "KH": "運動健康與休閒學系",
    "CCD": "工藝與創意設計學系", "DA": "建築學系", "EL": "東亞語文學系",
    "DAP": "運動競技學系", "LA": "法律學系", "GL": "政治法律學系",
    "FL": "財經法律學系", "AE": "應用經濟學系", "FI": "財務金融學系",
    "IM": "資訊管理學系", "AM": "應用數學系", "AC": "應用化學系",
    "AP": "應用物理學系", "EE": "電機工程學系", "CE": "土木與環境工程學系",
    "CS": "資訊工程學系", "CM": "化學工程及材料工程學系", "LS": "生命科學系",
    "AB": "亞太工商管理學系", "IFD": "創新學院不分系"
};

const SDGS_MAP = {
    "01": "消除貧窮", "02": "消除飢餓", "03": "健康與福祉", 
    "04": "優質教育", "05": "性別平等", "06": "淨水及衛生", 
    "07": "可負擔能源", "08": "就業與經濟成長", "09": "工業化、創新及基礎建設", 
    "10": "減少不平等", "11": "永續城市與社區", "12": "負責任的消費與生產", 
    "13": "氣候行動", "14": "保育海洋生態", "15": "保育陸地生態", 
    "16": "和平、正義與強大機構", "17": "多元夥伴關係"
};

// 🎯 【新增】教室代號對應大樓對照表
const BUILDING_MAP = {
    "K01": "運健休大樓",
    "L01": "圖資大樓",
    "L02": "法學院",
    "M01": "管理學院",
    "C01": "工學院",
    "B01": "綜合大樓",
    "C02": "理學院",
    "H1": "人文社會科學院",
    "H2": "人文社會科學院"
};

function viewCourseDetail(courseId) {
    const course = allCoursesRawData.find(c => c.id === courseId);
    if (!course) return;

    const deptKey = (course.department || '').toUpperCase().trim();
    const deptChineseName = DEPT_MAP[deptKey] || '其他';

    const max = course.maxStudents || 0;
    const confirmed = course.confirmedStudents || 0;
    const reqElective = course.requiredElective || '未註明';
    const courseCredits = course.credits !== undefined ? course.credits : 0;
    const courseRemarks = course.remarks || '無備註資訊。';

    // 🎯 【新增修改：上課教室大樓翻譯邏輯】
    let formattedClassroom = course.classroom || '未定';
    if (course.classroom && course.classroom.trim() !== "") {
        const originalRoom = course.classroom.trim();
        for (const [code, buildingName] of Object.entries(BUILDING_MAP)) {
            if (originalRoom.toUpperCase().startsWith(code)) {
                formattedClassroom = originalRoom.replace(new RegExp(code, 'i'), `${buildingName}(${code})`);
                break;
            }
        }
    }

    // 🎯 【核心修改：將後端的數字字串翻譯成優雅文字】
    let sdgsDisplay = "未設定SDGs目標";
    if (course.sdgs && course.sdgs.trim() !== "") {
        // 將 "01,08,02" 切開成陣列 ["01", "08", "02"]
        const sdgsArray = course.sdgs.split(",");
        const labels = ["最優先相關：", "第二相關：", "第三相關："];
        let lines = [];

        sdgsArray.forEach((num, index) => {
            const cleanNum = num.trim();
            if (SDGS_MAP[cleanNum]) {
                // 如果超出了三個，就用普通標籤
                const label = labels[index] || "相關目標："; 
                lines.push(`${label} ${cleanNum}. ${SDGS_MAP[cleanNum]}`);
            }
        });

        if (lines.length > 0) {
            sdgsDisplay = lines.join("\n"); // 用換行符號接起來
        }
    }

    let rateDisplay = "0% (0 / 0)";
    // 🎯 【新增】宣告一個變數用來存壓力量表的圖片檔名，預設為空值（未達 70% 就不顯示）
    let stressImageHtml = ""; 

    if (max > 0) {
        // 計算出純數字的百分比（例如 92.5）
        const percentageNum = (confirmed / max) * 100; 
        rateDisplay = `${percentageNum.toFixed(1)}% (${confirmed} / ${max})`;

        // 🎯 【新增】根據你給的規則，判斷該使用哪一張壓力量表圖片
        let imgName = "";
        if (percentageNum >= 95 && percentageNum <= 100) {
            imgName = "stress_level_meter_1.jpg";
        } else if (percentageNum >= 90 && percentageNum < 95) {
            imgName = "stress_level_meter_2.jpg";
        } else if (percentageNum >= 85 && percentageNum < 90) {
            imgName = "stress_level_meter_3.jpg";
        } else if (percentageNum >= 80 && percentageNum < 85) {
            imgName = "stress_level_meter_4.jpg";
        } else if (percentageNum >= 75 && percentageNum < 80) {
            imgName = "stress_level_meter_5.jpg";
        } else {
            // 🎯 只要小於 75%（包含 0% 到 74.9%），通通顯示第 6 張
            imgName = "stress_level_meter_6.jpg";
        }

        // 如果有符合的級距，就組裝成完整的 <img> 標籤（寬度與樣式可依據你的 CSS 調整）
        // 在 main.js 的 viewCourseDetail 函數裡，路徑要這樣寫：
        if (imgName !== "") {
            stressImageHtml = `<div class="mt-2 text-center">
                <img src="images/${imgName}" alt="壓力量表" class="img-fluid rounded shadow-sm" style="max-width: 100%;">
            </div>`;
        }
        
    } else if (confirmed > 0 && max === 0) {
        rateDisplay = `不限人數 (目前已選: ${confirmed}人)`;
    }

    // 填入前端 HTML
    document.getElementById('detailCode').innerText = `${course.department || ''}${course.courseCode || ''}`;
    document.getElementById('detailName').innerText = course.courseName || '無';
    document.getElementById('detailProfessor').innerText = course.professor || '未安排教師';
    document.getElementById('detailTime').innerText = `週${course.classDay || '無'} 第 ${course.classPeriod || '無'} 節`;
    document.getElementById('detailClassroom').innerText = course.classroom || '未定';
    // 🎯 【修改】改填入經過大樓名稱轉換後的變數
    document.getElementById('detailClassroom').innerText = formattedClassroom;
    document.getElementById('detailDept').innerText = deptChineseName;
    document.getElementById('detailRequired').innerText = reqElective;
    document.getElementById('detailCredits').innerText = `${courseCredits} 學分`;
    document.getElementById('detailRate').innerText = rateDisplay;
    // 🎯 【新增】將剛才組裝好的壓力量表 HTML（可能是圖片，也可能是空字串）塞入 Modal 的容器中
    // 注意：因為裡面有 <img> 標籤，所以要用 innerHTML
    const detailStressEl = document.getElementById('detailStress');
    if (detailStressEl) {
        detailStressEl.innerHTML = stressImageHtml; 
    }

    // 🎯 【新增】動態塞入右側大樓位置圖 HTML
    const detailMapEl = document.getElementById('detailMapContainer');
    if (detailMapEl) {
        detailMapEl.innerHTML = `
            <img src="images/classroom_map.jpg" alt="校園大樓地圖" class="img-fluid rounded" style="max-width: 100%; height: auto;">
        `;
    }

    document.getElementById('detailRemarks').innerText = courseRemarks;

    // 🎯 填入由前端解碼翻譯後的 SDGs 內容
    document.getElementById('detailSdgs').innerText = sdgsDisplay;

    const detailModal = new bootstrap.Modal(document.getElementById('courseDetailModal'));
    detailModal.show();
}

// ==========================================
// 🎯 這裡開始是新增的 【AI 課程諮詢】 前端功能邏輯
// ==========================================

// ==========================================
// 🎯 這裡開始是修正優化版：【AI 課程諮詢】（直接在頁面內勾選系所）
// ==========================================

// 在初始化或 DOM 載入時綁定 AI 頁面的 Checkbox 異動事件
document.addEventListener('DOMContentLoaded', () => {
    // 監聽 AI 面板中的勾選方塊，只要有勾選變動就即時更新文字提示
    document.body.addEventListener('change', (e) => {
        if (e.target && e.target.classList.contains('ai-dept-checkbox')) {
            updateAiSelectedDeptsText();
        }
    });
});

/**
 * 1. 處理左側邊欄的頁面切換
 */
function switchTab(tabId) {
    document.getElementById('course-list-tab').classList.remove('active');
    document.getElementById('ai-consult-tab').classList.remove('active');
    
    document.getElementById(tabId).classList.add('active');
    
    if (tabId === 'course-list-tab') {
        document.getElementById('courseListSection').style.display = 'block';
        document.getElementById('aiConsultSection').style.display = 'none';
    } else if (tabId === 'ai-consult-tab') {
        document.getElementById('courseListSection').style.display = 'none';
        document.getElementById('aiConsultSection').style.display = 'block';
        updateAiSelectedDeptsText(); // 切換過去時主動刷新按鈕文字與提示

        updateAiButtonStatus(); // 🎯 【新增】每次切換到 AI 分頁時，再次強制刷新按鈕狀態
    }
}

/**
 * 🎯 新增：專門用來控制 AI 諮詢按紐的啟用/禁用與視覺狀態
 */
function updateAiButtonStatus() {
    const sendBtn = document.getElementById('sendToAiBtn');
    if (!sendBtn) return; // 如果畫面上還沒渲染這個按鈕，直接跳出

    if (!currentUser) {
        // 🔒 未登入狀態：按鈕變灰色、上鎖、且禁用 (disabled)
        sendBtn.classList.remove('btn-primary');
        sendBtn.classList.add('btn-secondary');
        sendBtn.disabled = true; // 👈 讓按鈕徹底變成網頁無法點擊的狀態
        sendBtn.innerHTML = "<i class='bi bi-lock-fill me-2'></i>請先登入以解鎖 AI 智慧諮詢";
    } else {
        // 🔓 已登入狀態：恢復正常藍色、解鎖、可點擊
        sendBtn.classList.remove('btn-secondary');
        sendBtn.classList.add('btn-primary');
        sendBtn.disabled = false; // 👈 恢復可點擊
        sendBtn.innerHTML = "<i class='bi bi-send-fill me-2'></i>開始 AI 智慧諮詢";
    }
}

/**
 * 2. AI 專用的「全選 / 全不選」按鈕功能
 */
function aiFilterAllDepartments(isChecked) {
    const checkboxes = document.querySelectorAll('.ai-dept-checkbox');
    checkboxes.forEach(cb => cb.checked = isChecked);
    updateAiSelectedDeptsText();
}

/**
 * 3. 專門更新 AI 面板內下拉選單與資訊框的顯示文字
 */
function updateAiSelectedDeptsText() {
    const checkedBoxes = document.querySelectorAll('.ai-dept-checkbox:checked');
    const totalBoxes = document.querySelectorAll('.ai-dept-checkbox').length;
    const btn = document.getElementById('aiDeptDropdownBtn');
    const infoText = document.getElementById('aiSelectedDeptsText');
    
    if (!btn || !infoText) return;

    if (checkedBoxes.length === 0) {
        btn.innerText = "選擇諮詢系所 (已選擇: 0 個)";
        infoText.innerHTML = "<span class='text-danger'>❌ 未選擇任何系所，請先勾選系所範圍！</span>";
        return;
    }

    if (checkedBoxes.length === totalBoxes) {
        btn.innerText = "選擇諮詢系所 (已選擇: 全選)";
        infoText.innerText = "全選 (這將包含所有系所的課程背景知識)";
        return;
    }

    // 取得選中系所的中文名
    const names = Array.from(checkedBoxes).map(cb => {
        const code = cb.value;
        return DEPT_MAP[code] || code;
    });

    btn.innerText = `選擇諮詢系所 (已選擇: ${checkedBoxes.length} 個)`;
    infoText.innerText = names.join("、");

    // 🎯 【新增】當系所勾選狀態改變時，動態渲染第二層的課程 Checkbox
    renderAiCourseCheckboxes();
}

/**
 * 4. 核心 RAG 實作：從「AI 面板內」收集勾選系所的資料送交後端
 * 🎯 【全面升級】打包資訊時，多帶入 id, professor, classDay, classPeriod 給後端 RAG
 */
function askAiRecommendation() {
    if (!currentUser) {
        alert("登入提示：本功能僅開放給登入者使用，請先登入系統！");
        window.location.href = "login.html";
        return;
    }

    const userPrompt = document.getElementById('aiUserPrompt').value.trim();
    const responseBox = document.getElementById('aiResponseContainer');
    const spinner = document.getElementById('aiSpinner');
    const sendBtn = document.getElementById('sendToAiBtn');
    
    if (!userPrompt) {
        alert("請輸入您想諮詢的學習需求或興趣喔！");
        return;
    }
    
    const checkedDepts = Array.from(document.querySelectorAll('.ai-dept-checkbox:checked')).map(cb => cb.value);
    if (checkedDepts.length === 0) {
        alert("請先在第一步中勾選至少一個想諮詢的系所範圍！");
        return;
    }

    // 🎯 【關鍵修改】：改為抓取「課程 Checkbox」中被勾選的課程 ID 清單
    const checkedCourseIds = Array.from(document.querySelectorAll('.ai-course-checkbox:checked')).map(cb => parseInt(cb.value));
    
    if (checkedCourseIds.length === 0) {
        alert("您勾選了系所，但把所有課程都取消勾選了！請至少勾選一門想諮詢的課程。");
        return;
    }
    
    // 🎯 依據使用者在介面上精確勾選的課程 ID，過濾並打包大禮包送去後端
    const contextCourses = allCoursesRawData
        .filter(course => checkedCourseIds.includes(course.id)) // 👈 精準比對被選中的課程ID
        .map(course => {
            return {
                id: course.id,
                courseName: course.courseName || '未命名課程',
                courseObjectives: course.courseObjectives || '未提供教學目標',
                professor: course.professor || '未安排教師',
                classDay: course.classDay || '無',
                classPeriod: course.classPeriod || '無'
            };
        });
        
    // 啟動轉圈圈動畫
    spinner.classList.remove('d-none');
    responseBox.style.display = 'none';
    sendBtn.disabled = true;
    
    const payload = {
        departments: checkedDepts, // 保留系所代碼（以便後端記錄或分析）
        userPrompt: userPrompt,
        coursesData: contextCourses // 這裡已經變成「被使用者精挑細選後的課程清單」了！
    };
    
    // 發送 POST 請求給後端 Controller 
    fetch(`${API_BASE}/courses/ai-recommend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(res => {
        if (!res.ok) throw new Error("伺服器回應異常，請確認後端是否開機。");
        return res.json();
    })
    .then(data => {
        responseBox.innerHTML = marked.parse(data.result || "AI 未回傳任何推薦內容。");
    })
    .catch(err => {
        console.error("AI 諮詢失敗:", err);
        responseBox.innerText = `❌ 諮詢失敗：${err.message}`;
    })
    .finally(() => {
        spinner.classList.add('d-none');
        responseBox.style.display = 'block';
        sendBtn.disabled = false;
    });
}

/**
 * 🎯 【新增】根據目前 AI 面板勾選的系所，動態生成該系所的所有課程 Checkbox
 */
function renderAiCourseCheckboxes() {
    const container = document.getElementById('aiCourseCheckboxContainer');
    const controlBtns = document.getElementById('aiCourseControlBtns');
    if (!container) return;

    // 1. 拿到目前畫面上被勾選的 AI 系所代碼
    const checkedDepts = Array.from(document.querySelectorAll('.ai-dept-checkbox:checked')).map(cb => cb.value);

    // 如果沒選系所，顯示提示文字並隱藏控制鈕
    if (checkedDepts.length === 0) {
        container.innerHTML = '<span class="text-danger small">❌ 請先勾選上方系所範圍！</span>';
        if (controlBtns) controlBtns.style.setProperty('display', 'none', 'important');
        return;
    }

    // 2. 從全域原始資料中，撈出屬於這些系所的所有課程
    const filteredCourses = allCoursesRawData.filter(course => {
        return checkedDepts.includes((course.department || '').toUpperCase().trim());
    });

    if (filteredCourses.length === 0) {
        container.innerHTML = '<span class="text-muted small">⚠️ 所選系所目前無開課資料。</span>';
        if (controlBtns) controlBtns.style.setProperty('display', 'none', 'important');
        return;
    }

    // 顯示全選/全不選按鈕
    if (controlBtns) controlBtns.style.setProperty('display', 'flex', 'important');

    // 3. 動態渲染出 Checkbox 列表（預設全部打勾，方便使用者微調）
    let html = '';
    filteredCourses.forEach(course => {
        html += `
            <div class="col-md-6 col-sm-12">
                <label class="d-flex align-items-start text-start style="cursor: pointer;">
                    <input type="checkbox" class="ai-course-checkbox me-2 mt-1" value="${course.id}" checked>
                    <span class="small text-dark">
                        <strong>[${course.courseCode || '無課號'}]</strong> ${course.courseName} 
                        <span class="text-muted">(${course.professor || '未排教師'})</span>
                    </span>
                </label>
            </div>
        `;
    });

    container.innerHTML = html;
}

/**
 * 🎯 【新增】AI 課程選單的全選 / 全不選控制
 */
function aiFilterAllCourses(isChecked) {
    const checkboxes = document.querySelectorAll('.ai-course-checkbox');
    checkboxes.forEach(cb => cb.checked = isChecked);
}