// CourseController.java
package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.Course;
import com.example.demo.model.CourseDTO;
import com.example.demo.service.CourseService;
import com.example.demo.model.AiRequest;
import com.example.demo.model.Review;                //引入 Review 實體
import com.example.demo.repository.ReviewRepository; //引入 ReviewRepository
import org.springframework.data.domain.PageRequest;

@RestController
@RequestMapping("/api/courses")
@CrossOrigin(origins = "*")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @Autowired
    private ReviewRepository reviewRepository; //注入 Review 資料庫操作工具

    @GetMapping
    public ResponseEntity<List<CourseDTO>> getAllCourses() {
        List<CourseDTO> courses = courseService.getAllCoursesWithRating();
        return new ResponseEntity<>(courses, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Course> createCourse(@RequestBody Course course) {
        Course savedCourse = courseService.createCourse(course);
        return new ResponseEntity<>(savedCourse, HttpStatus.CREATED);
    }

    @Value("${gemini.api.key}")
    private String geminiApiKey;

    //接收篩選後的課程與問題，呼叫真正的 Gemini AI 進行課程推薦（含教授、時間、學長姐真實評論）
    @PostMapping("/ai-recommend")
    public ResponseEntity<Map<String, String>> getAiRecommendation(@RequestBody AiRequest aiRequest) {
        
        System.out.println("====== 收到 AI 諮詢請求 ======");
        System.out.println("使用者的問題: " + aiRequest.getUserPrompt());
        System.out.println("送入的參考課程數量: " + (aiRequest.getCoursesData() != null ? aiRequest.getCoursesData().size() : 0));

        // 1. 建立強大、資訊全面的 RAG System Prompt
        StringBuilder promptBuilder = new StringBuilder();
        promptBuilder.append("你是一位專業、親切的大學選課諮詢推薦者。請根據下方提供的課程清單（包含課程名稱、授課教授、上課時間、教學目標，以及「學長姐歷史真實評論」）來精準回答學生的提問。\n");
        promptBuilder.append("你的任務：\n");
        promptBuilder.append("1. 對比學生的興趣與目標，推薦最適合的課程並說明具體原因。\n");
        promptBuilder.append("2. 參考「學長姐歷史評論」，客觀分析教授的授課風格（例如：重實作、重理論、甜不甜、雷不雷、作業多不多）。\n");
        promptBuilder.append("3. 如果學生有時間衝突的疑慮，可以參考上課時間給予綜合排課建議。\n\n");
        
        promptBuilder.append("--- 【可供推薦的課程詳細資訊與學生評論範圍】 ---\n");
        
        if (aiRequest.getCoursesData() != null && !aiRequest.getCoursesData().isEmpty()) {
            for (AiRequest.CourseContext c : aiRequest.getCoursesData()) {
                
                String prof = (c.getProfessor() == null || c.getProfessor().isEmpty()) ? "未安排教師" : c.getProfessor();
                String timeStr = (c.getClassDay() == null || c.getClassPeriod() == null) ? "未定" : "週" + c.getClassDay() + " 第 " + c.getClassPeriod() + " 節";
                
                promptBuilder.append(String.format("【課程名稱】: %s\n", c.getCourseName()));
                promptBuilder.append(String.format("【授課教授】: %s\n", prof));
                promptBuilder.append(String.format("【上課時間】: %s\n", timeStr));
                promptBuilder.append(String.format("【教學目標】: %s\n", c.getCourseObjectives()));
                
                //動態從資料庫撈取這堂課【按讚數最多】的前 5 則學長姐評論
                promptBuilder.append("【學長姐真實歷史評論（優先排序高贊同度評論）】:\n");
                if (c.getId() != null) {
                    //直接調用新寫好的 Repository 方法，限定直接抓出 5 筆按讚最多的優質評論
                    List<Review> topReviews = reviewRepository.findTopReviewsByCourseIdOrderByLikes(c.getId(), PageRequest.of(0, 5));                    
                    if (topReviews != null && !topReviews.isEmpty()) {
                        for (Review r : topReviews) {
                            promptBuilder.append(String.format("  - (%d星評分) %s\n", r.getRating(), r.getContent()));
                        }
                    } else {
                        promptBuilder.append("  - (目前這門課程暫無學長姐留下歷史評論)\n");
                    }
                } else {
                    promptBuilder.append("  - (無法讀取課程ID，無法載入評論)\n");
                }
                promptBuilder.append("\n--------------------------------------------------\n\n");
            }
        } else {
            promptBuilder.append("(目前選取系所無課程資料)\n\n");
        }
        
        promptBuilder.append("--- 【使用者的具體諮詢問題】 ---\n");
        promptBuilder.append(aiRequest.getUserPrompt()).append("\n\n");
        promptBuilder.append("請用繁體中文回答。請讓回答結構清晰（多利用 Markdown 標題、粗體、條列式列表），口吻富有親和力，切中痛點，並大膽活用學長姐評論來做教授特質分析。");

        String finalPrompt = promptBuilder.toString();

        // 2. 組裝 Gemini API 所需的 JSON 資料結構
        Map<String, Object> textPart = new HashMap<>();
        textPart.put("text", finalPrompt);

        Map<String, Object> partsContainer = new HashMap<>();
        partsContainer.put("parts", List.of(textPart));

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("contents", List.of(partsContainer));

        // 根據最新 API 規範，將關鍵字改為 "googleSearch"
        // 新的 JSON 結構對應： "tools": [{"googleSearch": {}}]
        Map<String, Object> googleSearch = new HashMap<>(); // 空的物件 {}
        
        Map<String, Object> toolElement = new HashMap<>();
        toolElement.put("googleSearch", googleSearch); //修正為官方指定的 "googleSearch"
        
        // 將 toolElement 放入 List 中，再塞進 requestBody
        requestBody.put("tools", List.of(toolElement));


        // 3. 設定 Gemini API 請求網址 (使用 gemini-2.5-flash)
        //注意：因為開啟了網路搜尋等進階 Tools 功能，網址建議維持使用 v1beta 版本
        String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + geminiApiKey;

        String aiResultText;
        try {
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<Map> response = restTemplate.postForEntity(url, requestBody, Map.class);
            
            // 4. 解析 Gemini 回傳的複雜 JSON 結構
            Map responseBody = response.getBody();
            List candidates = (List) responseBody.get("candidates");
            Map firstCandidate = (Map) candidates.get(0);
            Map content = (Map) firstCandidate.get("content");
            List parts = (List) content.get("parts");
            Map firstPart = (Map) parts.get(0);
            
            aiResultText = (String) firstPart.get("text");

            // 額外小提示：Gemini 如果有上網查資料，回傳的 JSON 裡會包含 "groundingMetadata" 欄位，
            // 裡面有搜尋到的網頁來源連結。你目前直接拿 text 就可以正常顯示含有網路資料的文字回答了！

        } catch (Exception e) {
            e.printStackTrace();
            aiResultText = "呼叫 Gemini API 時發生錯誤：" + e.getMessage() + "\n請確認後端 API Key 是否配置正確且網路暢通。";
        }

        // 5. 包裝成前端需要的 JSON 回傳
        Map<String, String> resultJson = new HashMap<>();
        resultJson.put("result", aiResultText);
        
        return new ResponseEntity<>(resultJson, HttpStatus.OK);
    }
}