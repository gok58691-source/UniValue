//CourseDTO.java
package com.example.demo.model;

public class CourseDTO {
    private Long id;
    private String courseCode;
    private String courseName;
    private String professor;
    private String department;
    private double averageRating;
    private String classroom;
    private String classDay;
    private String classPeriod;
    private String requiredElective;
    private Integer credits;
    private Integer maxStudents;
    private Integer confirmedStudents;
    private String remarks;
    private String sdgs;

    private String courseObjectives;

    //完整建構子：讓 Service 可以把所有資料塞進來
    public CourseDTO(Long id, String courseCode, String courseName, String professor, String department, 
                 double averageRating, String classroom, String classDay, String classPeriod,
                 String requiredElective, Integer credits, Integer maxStudents, Integer confirmedStudents, 
                 String remarks, String sdgs, String courseObjectives) {
        this.id = id;
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.professor = professor;
        this.department = department;
        this.averageRating = averageRating;
        this.classroom = classroom;
        this.classDay = classDay;
        this.classPeriod = classPeriod;
        this.requiredElective = requiredElective;
        this.credits = credits;
        this.maxStudents = maxStudents;
        this.confirmedStudents = confirmedStudents;
        this.remarks = remarks;
        this.sdgs = sdgs;
        this.courseObjectives = courseObjectives;
    }

    // ====== Getters & Setters ======
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public String getProfessor() { return professor; }
    public void setProfessor(String professor) { this.professor = professor; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public double getAverageRating() { return averageRating; }
    public void setAverageRating(double averageRating) { this.averageRating = averageRating; }
    public String getClassroom() { return classroom; }
    public void setClassroom(String classroom) { this.classroom = classroom; }
    public String getClassDay() { return classDay; }
    public void setClassDay(String classDay) { this.classDay = classDay; }
    public String getClassPeriod() { return classPeriod; }
    public void setClassPeriod(String classPeriod) { this.classPeriod = classPeriod; }
    public String getRequiredElective() { return requiredElective; }
    public void setRequiredElective(String requiredElective) { this.requiredElective = requiredElective; }
    public Integer getCredits() { return credits; }
    public void setCredits(Integer credits) { this.credits = credits; }
    public Integer getMaxStudents() { return maxStudents; }
    public void setMaxStudents(Integer maxStudents) { this.maxStudents = maxStudents; }
    public Integer getConfirmedStudents() { return confirmedStudents; }
    public void setConfirmedStudents(Integer confirmedStudents) { this.confirmedStudents = confirmedStudents; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
    public String getSdgs() { return sdgs; }
    public void setSdgs(String sdgs) { this.sdgs = sdgs; }
    public String getCourseObjectives() { return courseObjectives; }
    public void setCourseObjectives(String courseObjectives) { this.courseObjectives = courseObjectives; }
}