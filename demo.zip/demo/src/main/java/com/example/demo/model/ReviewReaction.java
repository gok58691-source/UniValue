package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "review_reactions", 
       uniqueConstraints = {@UniqueConstraint(columnNames = {"review_id", "user_id"})})
public class ReviewReaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "review_id", nullable = false)
    private Long reviewId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Enumerated(EnumType.STRING)
    @Column(name = "reaction_type", nullable = false)
    private ReactionType reactionType;

    public ReviewReaction() {}

    public ReviewReaction(Long reviewId, Long userId, ReactionType reactionType) {
        this.reviewId = reviewId;
        this.userId = userId;
        this.reactionType = reactionType;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getReviewId() { return reviewId; }
    public void setReviewId(Long reviewId) { this.reviewId = reviewId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public ReactionType getReactionType() { return reactionType; }
    public void setReactionType(ReactionType reactionType) { this.reactionType = reactionType; }
}