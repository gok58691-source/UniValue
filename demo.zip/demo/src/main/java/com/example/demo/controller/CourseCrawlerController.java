//CourseCrawlerController.java
package com.example.demo.controller;

import com.example.demo.service.CourseCrawlerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/crawler")
@CrossOrigin(origins = "*")
public class CourseCrawlerController {

    @Autowired
    private CourseCrawlerService courseCrawlerService;

    @PostMapping("/start")
    public ResponseEntity<?> startCrawler(
            @RequestParam(defaultValue = "114") String year,
            @RequestParam(defaultValue = "2") String semester,
            @RequestHeader(value = "User-Role", required = false) String userRole) { //接收前端傳來的角色 Header
        
        //後端終極防線：如果 Header 不是 ADMIN，直接開除拒絕存取 (403 Forbidden)
        if (userRole == null || !userRole.equalsIgnoreCase("ADMIN")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("status", "fail", "message", "⚠️ 拒絕存取：您沒有管理員權限！"));
        }

        System.out.println("=== 管理員認證成功：啟動高大爬蟲任務 ===");
        int count = courseCrawlerService.crawlAndSaveCourses(year, semester);
        
        return ResponseEntity.ok(Map.of(
            "status", "success",
            "message", "高雄大學課程資訊更新完成！",
            "targetSemester", year + "學年度第" + semester + "學期",
            "totalProcessed", count
        ));
    }
}