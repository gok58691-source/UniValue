package com.example.demo.repository;

import com.example.demo.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {
    //修正：保留這個給爬蟲啟動時安全性清空用的方法
    @Transactional
    void deleteByOpenYearAndHelf(String openYear, String helf);
}