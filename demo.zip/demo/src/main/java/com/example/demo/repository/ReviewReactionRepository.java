package com.example.demo.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.demo.model.ReviewReaction;
import com.example.demo.model.ReactionType;

@Repository
public interface ReviewReactionRepository extends JpaRepository<ReviewReaction, Long> {
    
    // 尋找某使用者是否對某評論有按讚紀錄
    Optional<ReviewReaction> findByReviewIdAndUserId(Long reviewId, Long userId);

    // 統計某評論的讚數或倒讚數
    long countByReviewIdAndReactionType(Long reviewId, ReactionType reactionType);
}