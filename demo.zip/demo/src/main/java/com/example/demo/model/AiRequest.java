// AiRequest.java
package com.example.demo.model;

import java.util.List;

public class AiRequest {
    private List<String> departments; 
    private String userPrompt;        
    private List<CourseContext> coursesData; 

    // Getters and Setters
    public List<String> getDepartments() { return departments; }
    public void setDepartments(List<String> departments) { this.departments = departments; }
    
    public String getUserPrompt() { return userPrompt; }
    public void setUserPrompt(String userPrompt) { this.userPrompt = userPrompt; }
    
    public List<CourseContext> getCoursesData() { return coursesData; }
    public void setCoursesData(List<CourseContext> coursesData) { this.coursesData = coursesData; }

    public static class CourseContext {
        private Long id;                 // 用來讓後端查評論
        private String courseName;
        private String courseObjectives;
        private String professor;        // 教授
        private String classDay;         // 週幾
        private String classPeriod;      // 節次

        // 新欄位的 Getters and Setters
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }

        public String getCourseName() { return courseName; }
        public void setCourseName(String courseName) { this.courseName = courseName; }
        
        public String getCourseObjectives() { return courseObjectives; }
        public void setCourseObjectives(String courseObjectives) { this.courseObjectives = courseObjectives; }

        public String getProfessor() { return professor; }
        public void setProfessor(String professor) { this.professor = professor; }

        public String getClassDay() { return classDay; }
        public void setClassDay(String classDay) { this.classDay = classDay; }

        public String getClassPeriod() { return classPeriod; }
        public void setClassPeriod(String classPeriod) { this.classPeriod = classPeriod; }
    }
}