package com.example.demo.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Review;
import com.example.demo.model.ReviewReaction;
import com.example.demo.model.ReactionType;
import com.example.demo.repository.ReviewRepository;
import com.example.demo.repository.ReviewReactionRepository;

@RestController
@RequestMapping("/api/reviews")
@CrossOrigin(origins = "*")
public class ReviewController {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private ReviewReactionRepository reviewReactionRepository;

    //1. 學生送出評論
    @PostMapping
    public ResponseEntity<Review> createReview(@RequestBody Review review) {
        Review savedReview = reviewRepository.save(review);
        return new ResponseEntity<>(savedReview, HttpStatus.CREATED);
    }

    /**
     * 2. 根據課程 ID 取得評論清單（支援傳入目前 userId 來載入讚數與按讚狀態）
     * 網址範例：GET http://localhost:8080/api/reviews/course/1?userId=5
     */
    @GetMapping("/course/{courseId}")
    public ResponseEntity<List<Review>> getReviewsByCourse(
            @PathVariable Long courseId,
            @RequestParam(required = false) Long userId) {
        
        List<Review> reviews = reviewRepository.findByCourseId(courseId);
        
        //針對每一筆評論，動態計算讚數、倒讚數以及當前用戶的點擊狀態
        for (Review r : reviews) {
            long likes = reviewReactionRepository.countByReviewIdAndReactionType(r.getId(), ReactionType.LIKE);
            long dislikes = reviewReactionRepository.countByReviewIdAndReactionType(r.getId(), ReactionType.DISLIKE);
            r.setLikeCount(likes);
            r.setDislikeCount(dislikes);
            
            if (userId != null) {
                Optional<ReviewReaction> reactionOpt = reviewReactionRepository.findByReviewIdAndUserId(r.getId(), userId);
                if (reactionOpt.isPresent()) {
                    r.setUserReaction(reactionOpt.get().getReactionType().name());
                } else {
                    r.setUserReaction("NONE");
                }
            }
        }
        
        return new ResponseEntity<>(reviews, HttpStatus.OK);
    }

    /**
     * 3. 處理點擊讚/倒讚的綜合觸發 API
     * 網址：POST http://localhost:8080/api/reviews/{reviewId}/react?userId=5&type=LIKE
     */
    @PostMapping("/{reviewId}/react")
    public ResponseEntity<?> reactToReview(
            @PathVariable Long reviewId,
            @RequestParam Long userId,
            @RequestParam String type) {
        
        // 檢查評論是否存在
        if (!reviewRepository.existsById(reviewId)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("評論不存在");
        }

        ReactionType targetType;
        try {
            targetType = ReactionType.valueOf(type.toUpperCase());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("不合法的反應型態，必須為 LIKE 或 DISLIKE");
        }

        // 尋找有無舊紀錄
        Optional<ReviewReaction> existingReaction = reviewReactionRepository.findByReviewIdAndUserId(reviewId, userId);

        if (existingReaction.isPresent()) {
            ReviewReaction oldReaction = existingReaction.get();
            if (oldReaction.getReactionType() == targetType) {
                // 狀況 A：再度點擊相同按鈕 -> 視同「取消按讚/取消倒讚」
                reviewReactionRepository.delete(oldReaction);
            } else {
                // 狀況 B：點擊相反按鈕 -> 變更狀態（例如讚變成倒讚）
                oldReaction.setReactionType(targetType);
                reviewReactionRepository.save(oldReaction);
            }
        } else {
            // 狀況 C：全新點擊 -> 直接新增一筆紀錄
            ReviewReaction newReaction = new ReviewReaction(reviewId, userId, targetType);
            reviewReactionRepository.save(newReaction);
        }

        // 重新計算最新數值並回傳給前端，讓前端直接無縫刷新 UI 數字
        long likes = reviewReactionRepository.countByReviewIdAndReactionType(reviewId, ReactionType.LIKE);
        long dislikes = reviewReactionRepository.countByReviewIdAndReactionType(reviewId, ReactionType.DISLIKE);
        
        // 再撈一次使用者最新狀態
        String currentStatus = reviewReactionRepository.findByReviewIdAndUserId(reviewId, userId)
                .map(r -> r.getReactionType().name())
                .orElse("NONE");

        // 回傳一個簡單的 JSON 結構物件
        return ResponseEntity.ok(java.util.Map.of(
            "likeCount", likes,
            "dislikeCount", dislikes,
            "userReaction", currentStatus
        ));
    }
}