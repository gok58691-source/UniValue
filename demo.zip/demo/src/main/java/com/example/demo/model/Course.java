//Course.java
package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "courses")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "open_year")
    private String openYear;

    private String helf;
    private String department;

    @Column(name = "course_code")
    private String courseCode; // 正確對應 A012

    @Column(name = "course_name")
    private String courseName; // 正確對應 生活經濟學

    private String professor;   // 正確對應 鄭義暉
    
    @Column(name = "class_group")
    private String classGroup; // 正確對應 A
    
    private String classroom;   // 正確對應 M01-206

    @Column(name = "max_students")
    private Integer maxStudents; // 正確對應 60

    @Column(name = "confirmed_students")
    private Integer confirmedStudents; // 正確對應 60

    private Integer credits; // 正確對應 2
    private Integer grade;   // 正確對應 1
    private String pclass;   // 原始資料的開課部別代碼（如：A）

    @Column(name = "required_elective")
    private String requiredElective; // 正確對應 選

    @Column(columnDefinition = "TEXT")
    private String remarks; // 正確對應 管院同學請勿選修

    @Column(name = "average_rating")
    private Double averageRating = 0.0;

    @Column(name = "class_day")
    private String classDay; // 儲存：四

    @Column(name = "class_period")
    private String classPeriod; // 儲存：3,4

    // 在 Course.java 裡新增屬性：
    @Column(length = 50)
    private String sdgs; // 儲存格式如: "01,08,02" 或 "10"

    @Column(name = "course_objectives", columnDefinition = "TEXT")
    private String courseObjectives; // 儲存詳細的教學目標文字

    // ====== 以下手動補上或利用 IDE 自動生成所有 Getters & Setters ======
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getOpenYear() { return openYear; }
    public void setOpenYear(String openYear) { this.openYear = openYear; }
    public String getHelf() { return helf; }
    public void setHelf(String helf) { this.helf = helf; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public String getProfessor() { return professor; }
    public void setProfessor(String professor) { this.professor = professor; }
    public String getClassGroup() { return classGroup; }
    public void setClassGroup(String classGroup) { this.classGroup = classGroup; }
    public String getClassroom() { return classroom; }
    public void setClassroom(String classroom) { this.classroom = classroom; }
    public Integer getMaxStudents() { return maxStudents; }
    public void setMaxStudents(Integer maxStudents) { this.maxStudents = maxStudents; }
    public Integer getConfirmedStudents() { return confirmedStudents; }
    public void setConfirmedStudents(Integer confirmedStudents) { this.confirmedStudents = confirmedStudents; }
    public Integer getCredits() { return credits; }
    public void setCredits(Integer credits) { this.credits = credits; }
    public Integer getGrade() { return grade; }
    public void setGrade(Integer grade) { this.grade = grade; }
    public String getPclass() { return pclass; }
    public void setPclass(String pclass) { this.pclass = pclass; }
    public String getRequiredElective() { return requiredElective; }
    public void setRequiredElective(String requiredElective) { this.requiredElective = requiredElective; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
    public Double getAverageRating() { return averageRating; }
    public void setAverageRating(Double averageRating) { this.averageRating = averageRating; }
    public String getClassDay() { return classDay; }
    public void setClassDay(String classDay) { this.classDay = classDay; }
    public String getClassPeriod() { return classPeriod; }
    public void setClassPeriod(String classPeriod) { this.classPeriod = classPeriod; }
    public String getSdgs() { return sdgs; }
    public void setSdgs(String sdgs) { this.sdgs = sdgs; }
    public String getCourseObjectives() { return courseObjectives; }
    public void setCourseObjectives(String courseObjectives) { this.courseObjectives = courseObjectives; }
}