package com.example.demo.repository;

import com.example.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    // 讓 Spring Data JPA 自動幫我們生成「根據帳密尋找使用者」的 SQL
    User findByUsernameAndPassword(String username, String password);
    
    // 檢查帳號是否已經被註冊過
    boolean existsByUsername(String username);
}