//Review.java
package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "reviews") // 對應 phpMyAdmin 中的 reviews 資料表
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // 設定 id 為自動遞增 (AUTO_INCREMENT)
    private Long id;

    // 解決 500 錯誤的關鍵：強制將 Java 的 courseId 對應到資料庫的 course_id 欄位
    @Column(name = "course_id", nullable = false)
    private Long courseId;

    // 強制將 Java 的 userId 對應到資料庫的 user_id 欄位
    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(nullable = false)
    private String username;

    @Column(nullable = false)
    private Integer rating; // 星等 (1-5)

    // columnDefinition = "TEXT" 允許儲存較長的評論文字
    @Column(columnDefinition = "TEXT", nullable = false)
    private String content;

    // 自動記錄評論建立時間
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    // --- 這是 JPA 的生命週期註解，在資料寫入資料庫前，自動幫你補上當前時間 ---
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    //【防重複按讚機制專用非持久化欄位】
    @Transient
    private long likeCount = 0;

    @Transient
    private long dislikeCount = 0;

    @Transient
    private String userReaction = "NONE"; // 目前使用者對此評論的狀態：'LIKE', 'DISLIKE' 或 'NONE'

    // --- 建構子 (Constructor) ---
    public Review() {
    }

    public Review(Long courseId, Long userId, String username, Integer rating, String content) {
        this.courseId = courseId;
        this.userId = userId;
        this.username = username;
        this.rating = rating;
        this.content = content;
    }

    // --- Getter 和 Setter (讓 Controller 可以讀寫資料) ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public Long getCourseId() { return courseId; }
    public void setCourseId(Long courseId) { this.courseId = courseId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public Integer getRating() { return rating; }
    public void setRating(Integer rating) { this.rating = rating; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public long getLikeCount() { return likeCount; }
    public void setLikeCount(long likeCount) { this.likeCount = likeCount; }

    public long getDislikeCount() { return dislikeCount; }
    public void setDislikeCount(long dislikeCount) { this.dislikeCount = dislikeCount; }

    public String getUserReaction() { return userReaction; }
    public void setUserReaction(String userReaction) { this.userReaction = userReaction; }
}
