package com.example.demo.service;

import com.example.demo.model.Course;
import com.example.demo.repository.CourseRepository;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils; // 引入 Spring 的 HTML 解碼工具

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class CourseCrawlerService {

    @Autowired
    private CourseRepository courseRepository;

    //優化：全面解決 HTML 實體編碼還原後，中/英/數位字元之間產生的奇怪裂開空格
    private String cleanHtmlText(String rawText) {
        if (rawText == null) return "";
        
        // 1. 先將 HTML 實體編碼（如 &#27963;）還原成正常文字
        String decoded = HtmlUtils.htmlUnescape(rawText);
        
        // 2. 移除所有的 <br> 或 <br/> 標籤，避免它們干擾文字合併，並用空格暫代
        decoded = decoded.replaceAll("(?i)<br\\s*/?>", " ");
        
        // 3. 終極優化正規表示式：
        // 前瞻與後顧條件改為：[\u4e00-\u9fa5a-zA-Z0-9] 
        // 意即：只要空格「前面」與「後面」都是中文字、英文字母或數字，就將該空格「消除」！
        // 這樣可以精準修復 "j ava" -> "java"、"生 活" -> "生活"，但同時保留 "Java Programming" 這種單字間的合法空格！
        decoded = decoded.replaceAll("(?<=[\u4e00-\u9fa5a-zA-Z0-9])\\s+(?=[\u4e00-\u9fa5a-zA-Z0-9])", "");
        
        // 4. 將多個連續的空白（若有剩下的合法空格）縮減為單個空格，保持排版美觀
        decoded = decoded.replaceAll("\\s+", " ");
        
        return decoded.trim();
    }

    public int crawlAndSaveCourses(String year, String semester) {
        int savedCount = 0;

        try {
            System.out.println("⚠️ [安全性重置] 正在清空 " + year + "學年度第" + semester + "學期 的舊課程...");
            courseRepository.deleteByOpenYearAndHelf(year, semester);

            for (int page = 1; page <= 50; page++) {
                String fileName = "courses/course_" + page + ".html";
                ClassPathResource resource = new ClassPathResource(fileName);
                
                if (!resource.exists()) {
                    System.out.println("[完工提示] 找不到 " + fileName + "，多檔案同步全面結束。");
                    break;
                }

                System.out.println("====== 開始完整解析第 " + page + " 頁: " + fileName + " ======");
                File htmlFile = resource.getFile();
                Document doc = Jsoup.parse(htmlFile, StandardCharsets.UTF_8.name());

                Element courseTable = null;
                Elements tables = doc.select("table");
                for (Element t : tables) {
                    if (t.text().contains("課號") && t.text().contains("課程名稱")) {
                        courseTable = t;
                        break;
                    }
                }

                if (courseTable == null) continue;
                Elements rows = courseTable.select("tr[align=center]");
                int pageSaved = 0;

                for (Element row : rows) {
                    try {
                        if (row.text().contains("系所") || row.text().contains("課號")) continue;

                        Elements allTds = row.select("td");
                        List<Element> visibleTds = new ArrayList<>();
                        for (Element td : allTds) {
                            String style = td.attr("style");
                            if (!style.contains("display:none")) {
                                visibleTds.add(td);
                            }
                        }

                        if (visibleTds.size() < 12) continue;

                        String department = visibleTds.get(0).text().trim();          
                        String courseCode = visibleTds.get(1).text().trim();          
                        String pclass = visibleTds.get(2).text().trim();              
                        String gradeStr = visibleTds.get(3).text().trim();            
                        String classGroup = visibleTds.get(4).text().trim();          
                        
                        // 課程名稱與超連結抓取
                        String courseName = "";
                        String detailHref = ""; 
                        Element courseLink = visibleTds.get(5).select("a").first();
                        if (courseLink != null) {
                            // 修改這裡：抓取 html() 原始代碼，這樣才能完整拿到 &#27963; 並交給 cleanHtmlText 處理
                            courseName = cleanHtmlText(courseLink.html());
                            detailHref = courseLink.attr("href").trim(); 
                        } else {
                            courseName = cleanHtmlText(visibleTds.get(5).html());
                        }

                        if (courseName.isEmpty()) continue;

                        String creditsStr = visibleTds.get(6).text().trim();          
                        String requiredElective = visibleTds.get(7).text().trim();     
                        String maxStudentsStr = visibleTds.get(8).text().trim();       
                        String confirmedStudentsStr = visibleTds.get(9).text().trim(); 
                        String professor = visibleTds.get(12).text().trim();          
                        String classroom = visibleTds.get(13).text().trim();          

                        // 時間動態掃描
                        String classDay = "";
                        String classPeriod = "";
                        String[] weekDays = {"一", "二", "三", "四", "五", "六", "日"};
                        for (int i = 0; i < 7; i++) {
                            int targetIdx = 14 + i;
                            if (targetIdx < visibleTds.size()) {
                                String cellText = visibleTds.get(targetIdx).text().trim();
                                if (cellText.matches(".*\\d+.*")) {
                                    classDay = weekDays[i];
                                    classPeriod = cellText;
                                    break; 
                                }
                            }
                        }

                        String remarks = visibleTds.size() > 22 ? visibleTds.get(22).text().trim() : visibleTds.get(visibleTds.size() - 1).text().trim();

                        String sdgsResult = "未設定SDGs目標";
                        String objectivesResult = "未提供教學目標";

                        if (!detailHref.isEmpty()) {
                            Document detailDoc = fetchDetailDocument(detailHref, courseCode);
                            if (detailDoc != null) {
                                sdgsResult = parseSdgs(detailDoc, courseCode);
                                // 修改：在解析教學目標時，也一併呼叫清洗函式
                                objectivesResult = cleanHtmlText(parseCourseObjectives(detailDoc));
                            }
                        }

                        // 型態轉換
                        Integer grade = (gradeStr != null && gradeStr.matches("\\d+")) ? Integer.parseInt(gradeStr) : null;
                        Integer credits = (creditsStr != null && creditsStr.matches("\\d+")) ? Integer.parseInt(creditsStr) : 0;
                        Integer maxStudents = (maxStudentsStr != null && maxStudentsStr.matches("\\d+")) ? Integer.parseInt(maxStudentsStr) : 0;
                        Integer confirmedStudents = (confirmedStudentsStr != null && confirmedStudentsStr.matches("\\d+")) ? Integer.parseInt(confirmedStudentsStr) : 0;

                        // 儲存至資料庫
                        Course course = new Course();
                        course.setOpenYear(year);
                        course.setHelf(semester);
                        course.setDepartment(department);
                        course.setCourseCode(courseCode);
                        course.setPclass(pclass);
                        course.setGrade(grade);
                        course.setClassGroup(classGroup);
                        course.setCourseName(courseName); // 已清洗後的乾淨名稱
                        course.setCredits(credits);
                        course.setRequiredElective(requiredElective);
                        course.setMaxStudents(maxStudents);
                        course.setConfirmedStudents(confirmedStudents);
                        course.setProfessor(professor);
                        course.setClassroom(classroom);
                        course.setRemarks(remarks);
                        course.setClassDay(classDay);
                        course.setClassPeriod(classPeriod);
                        course.setSdgs(sdgsResult); 
                        course.setCourseObjectives(objectivesResult); // 已清洗後的乾淨教學目標

                        courseRepository.save(course);
                        savedCount++;
                        pageSaved++;

                    } catch (Exception rowException) {
                        System.err.println("⚠️ [跳過單一異常課程] " + rowException.getMessage());
                    }
                }
                System.out.println("✅ 第 " + page + " 頁處理完畢！本頁成功同步 " + pageSaved + " 門課。");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return savedCount;
    }

    private Document fetchDetailDocument(String href, String courseCode) {
        try {
            String localPath = "courses/details/" + courseCode + ".html";
            ClassPathResource resource = new ClassPathResource(localPath);
            if (resource.exists()) {
                return Jsoup.parse(resource.getFile(), "UTF-8");
            } else {
                String cleanHref = href.trim();
                if (cleanHref.startsWith("/")) cleanHref = cleanHref.substring(1);
                String fullUrl = "https://course.nuk.edu.tw/QueryCourse/" + cleanHref;
                return Jsoup.connect(fullUrl)
                        .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                        .timeout(10000)
                        .get();
            }
        } catch (Exception e) {
            System.out.println("[❌ 詳情頁讀取失敗] 課號 " + courseCode + " 原因: " + e.getMessage());
            return null;
        }
    }

    private String parseSdgs(Document detailDoc, String courseCode) {
        try {
            for (Element table : detailDoc.select("table")) {
                String tableHtml = table.html();
                if (tableHtml.contains("聯合國全球永續發展目標") || tableHtml.contains("Sustainable Development Goals")) {
                    for (Element td : table.select("td")) {
                        String tdText = td.text();
                        if (tdText.contains("最優先相關") || tdText.contains("相關：")) {
                            List<String> sdgsList = new ArrayList<>();
                            Matcher matcher = Pattern.compile("\\d{2}").matcher(tdText);
                            while (matcher.find()) {
                                String sdgNo = matcher.group();
                                int num = Integer.parseInt(sdgNo);
                                if (num >= 1 && num <= 17 && !sdgsList.contains(sdgNo)) {
                                    sdgsList.add(sdgNo);
                                }
                            }
                            if (!sdgsList.isEmpty()) return String.join(",", sdgsList);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("解析 SDGs 錯誤: " + e.getMessage());
        }
        return "";
    }

    private String parseCourseObjectives(Document detailDoc) {
        try {
            // 這裡改抓 html() 原始內容送出，防止特殊字元中斷
            Elements objectiveHeaders = detailDoc.select("td:contains(教學目標 Objectives), td:contains(教學目標)");
            
            for (Element headerTd : objectiveHeaders) {
                Element currentTr = headerTd.parent();
                if (currentTr == null || !currentTr.tagName().equals("tr")) continue;
                
                Element nextTr = currentTr.nextElementSibling();
                if (nextTr != null && nextTr.tagName().equals("tr")) {
                    Element targetTd = nextTr.select("td").first();
                    if (targetTd != null) {
                        String htmlContent = targetTd.html().trim();
                        if (!htmlContent.isEmpty()) {
                            return htmlContent;
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("解析教學目標錯誤: " + e.getMessage());
        }
        return "未提供教學目標";
    }
}