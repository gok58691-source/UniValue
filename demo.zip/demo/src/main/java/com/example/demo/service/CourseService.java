//CourseService.java
package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Course;
import com.example.demo.model.CourseDTO;
import com.example.demo.model.Review;
import com.example.demo.repository.CourseRepository;
import com.example.demo.repository.ReviewRepository;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private ReviewRepository reviewRepository;

    public List<CourseDTO> getAllCoursesWithRating() {
        List<Course> courses = courseRepository.findAll();
        
        return courses.stream().map(course -> {
            List<Review> reviews = reviewRepository.findByCourseId(course.getId());
            double avg = reviews.stream().mapToInt(Review::getRating).average().orElse(0.0);
            avg = Math.round(avg * 10.0) / 10.0;
            
            //將 Course 實體內的所有欄位，毫無遺漏地依序餵給 CourseDTO
            return new CourseDTO(
                course.getId(), 
                course.getCourseCode(),
                course.getCourseName(), 
                course.getProfessor(), 
                course.getDepartment(),   
                avg,
                course.getClassroom(),   
                course.getClassDay(),     
                course.getClassPeriod(),
                course.getRequiredElective(),
                course.getCredits(), 
                course.getMaxStudents(), 
                course.getConfirmedStudents(), 
                course.getRemarks(), 
                course.getSdgs(),
                course.getCourseObjectives() //教學目標
            );
        }).collect(Collectors.toList());
    }

    public Course createCourse(Course course) {
        return courseRepository.save(course);
    }
}