package com.example.demo.repository;

import java.util.List;
import org.springframework.data.domain.Pageable; // 引入套件
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.example.demo.model.Review;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    
    List<Review> findByCourseId(Long courseId);

    // 移除 SQL 裡面的 LIMIT 語法，改由參數傳入 Pageable
    @Query(value = "SELECT r.* FROM reviews r " +
                   "LEFT JOIN review_reactions rr ON r.id = rr.review_id AND rr.reaction_type = 'LIKE' " +
                   "WHERE r.course_id = :courseId " +
                   "GROUP BY r.id " +
                   "ORDER BY COUNT(rr.id) DESC, r.created_at DESC", nativeQuery = true)
    List<Review> findTopReviewsByCourseIdOrderByLikes(@Param("courseId") Long courseId, Pageable pageable);
}